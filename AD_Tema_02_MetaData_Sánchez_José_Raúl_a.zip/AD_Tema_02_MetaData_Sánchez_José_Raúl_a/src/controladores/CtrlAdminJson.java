package controladores;

import com.google.gson.Gson;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author José Raúl Sánchez García
 */
public class CtrlAdminJson {
    //Atributos
    private Gson conversor;
    private String json;
    private File f;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public CtrlAdminJson() {
        this.conversor = new Gson();
        this.json = "";
    }
    
    
    public boolean crearFicheroJson(ArrayList<Object[]> listaObjetos) {
        boolean seHaCreado = false;
        BufferedWriter bw = null;
        try {
            this.f = new File("resultadoConsulta.json");
            bw = new BufferedWriter(new FileWriter(this.f));
        } catch (IOException ex) {
        }
        for (Object o : listaObjetos) {
            try {
                this.json = this.conversor.toJson(o);
                bw.write(this.json);
                bw.newLine();
                bw.newLine();
                seHaCreado = true;
            } catch (IOException ex) {
            }
        }
        try {
            bw.close();
        } catch (IOException ex) {
        } finally {
            return seHaCreado;
        }
    }
    
    public String getFileName(){
        return this.f.getName();
    }
}
