package controladores;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author José Raúl Sánchez García
 */
public class CtrlAdminFicheroObjeto {
    //Atributos
    private File f;
    private FileOutputStream fos;
    private FileInputStream fis;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    //Métodos
    //Constructor por defecto
    public CtrlAdminFicheroObjeto(){
        this.f = new File("resultadoCon.txt");
        try {
            this.fos = new FileOutputStream(this.f);
            this.oos = new ObjectOutputStream(this.fos);
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {}
    }
    
    
    public boolean escribirLista(ArrayList<Object[]> listaObjetos){
        boolean seHaCredo = false;
        try {
            this.oos.writeObject(listaObjetos);
            seHaCredo = true;
        } catch (IOException ex) {
        } finally{
            try {
                this.oos.close();
            } catch (IOException ex) {
            } finally{
                return seHaCredo;
            }
        }
    }
    
    public String getFileName(){
        return this.f.getName();
    }
}
