package controladores;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author José Raúl Sánchez García
 */
public class CtrlConexion {
    //Atributos
    private String cadenaConexion;
    private String esquema;
    private Connection con;
    private DatabaseMetaData dmd;
    private ResultSet rs;
    private ResultSet rs2;
    private Statement st;
    private ResultSetMetaData rsmd;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por parámetros
    public  Connection conectar(String servidor, String puerto, String usuario, String contrasena){
        this.cadenaConexion = "jdbc:oracle:thin:@" + servidor.trim() + ":" + puerto.trim() + ":" + "xe";
        try {
            this.con = DriverManager.getConnection(this.cadenaConexion, usuario, contrasena);
            this.dmd = this.con.getMetaData();
            this.esquema = usuario;
        } catch (SQLException ex) {this.con = null;
        } finally{
            return this.con;
        }
    }
    
    
    
    public ArrayList<String> getTablas(){
        ArrayList<String> tablas = new ArrayList<>();
        try {
            String[] tipoTablas = {"TABLE"};
            this.rs = this.dmd.getTables(null, esquema, "%", tipoTablas);
            while(this.rs.next()){
                tablas.add(this.rs.getString("TABLE_NAME"));
            }
        } catch (SQLException ex) {
        } finally{
            try {
                this.rs.close();
            } catch (SQLException ex) {
            } finally{
                return tablas;
            }
        }
    }
    
    public ArrayList<String> getNombresColumnas(String tabla){
        ArrayList<String> campos = new ArrayList<>();
        try {
            this.rs = this.dmd.getColumns(null, this.esquema, tabla, "%");
            while(this.rs.next()){
                campos.add(this.rs.getString("COLUMN_NAME"));
            }
        } catch (SQLException ex) {
        } finally {
            return campos;
        }
    }
    
    public String getTipoDato(String tabla, String campo){
        String tipo = "";
        String tipoAux = "";
        tabla = tabla.toUpperCase();
        campo = campo.toUpperCase();
        try {
            this.rs = this.dmd.getColumns(null, this.esquema, tabla, campo);
            while(this.rs.next()){
                tipoAux = this.rs.getString("TYPE_NAME");
                //Por cada tipo de dato devuelvo un mensaje distinto
                switch(tipoAux){
                    case "VARCHAR2":
                        tipo = "String";
                        break;
                    case "NUMBER":
                        tipo = "double";
                        break;
                    case "DATE":
                        tipo = "Date";
                        break;
                    default:
                        tipo = "Tipo de dato no controlado";
                }
            }
        } catch (SQLException ex) {
        } finally {
            try {
                this.rs.close();
            } catch (SQLException ex) {
            } finally {
                return tipo;
            }
        }
    }
    
    public String ejecutarConsulta(String ins){
        String msj = "";
        try {
            this.st = this.con.createStatement();
            this.rs2 = this.st.executeQuery(ins);
            /*while (rs2.next()){
                System.out.println("");
            
            }*/
            this.rsmd = this.rs2.getMetaData();
            msj = "";
        } catch (SQLException ex) {
            msj = ex.getSQLState();
        } finally{return msj;
        }
    }
    
    public int getNumColumnas(){
        int numColumnas = 0;
        if(this.rsmd != null){
            try {
                numColumnas = this.rsmd.getColumnCount();
            } catch (SQLException ex) {
            } finally {
                return numColumnas;
            }
        }
        return numColumnas;
    }
    
    public String getNombreColumna(int numColumna){
        String nombre = "";
        try {
            nombre = this.rsmd.getColumnName(numColumna);
        } catch (SQLException ex) { nombre = "";
        } finally {
            return nombre;
        }
    }    
    
    public String getTipoColumna(int numColumna, String nombreColumna){
        String dato = "";
        try {
            dato = this.rsmd.getColumnTypeName(numColumna);
        } catch (SQLException ex) {
        } finally {
            return dato;
        }
    }
    
    public String getCampo(String tipo, String nombre, boolean haySiguiente){
        String campo = "";
        if(haySiguiente){
            switch (tipo) {
                case "NUMBER":
                try {
                    try {
                        campo = String.valueOf(this.rs2.getDouble(nombre));
                    } catch(NumberFormatException ex) {
                        campo = String.valueOf(this.rs2.getInt(nombre));
                    }
                } catch (SQLException ex) {
                }
                break;
                case "VARCHAR2":
                try {
                    campo = this.rs2.getString(nombre);
                } catch (SQLException ex) {
                }
                break;
                case "DATE":
                try {
                    campo = this.rs2.getDate(nombre).toString();
                } catch (SQLException ex) {
                }
                break;
            }
        }
        return campo;
    }
    
    public boolean hayMasDatos(){
        boolean si = false;
        try {
            si = this.rs2.next();
        } catch(SQLException ex) { si = false;
        } finally{
            return si;
        }
    }
}
