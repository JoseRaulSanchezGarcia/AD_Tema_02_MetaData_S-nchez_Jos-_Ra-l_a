package vistas;

import controladores.CtrlAdminFicheroObjeto;
import controladores.CtrlAdminJson;
import controladores.CtrlConexion;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author José Raúl Sánchez García
 */
public class PantallaPrincipal extends javax.swing.JFrame {
    //Declaracion de variables
    private PantallaInicial inicio = null;
    private final CtrlConexion controlarCon = new CtrlConexion();
    private boolean estaConectada;
    private ArrayList<String> listaTablas;
    private ArrayList<String> listaCampos;
    private DefaultTableModel dtmCampos;
    private DefaultTableModel dtmCamposSelec;
    private DefaultTableModel dtmCondiciones;
    private String sentenciaSelect;
    private String sentenciaFrom;
    private String sentenciaWhere;
    private static int numCampos = 0;
    private static int numCondiciones = 0;
    private DefaultTableModel dtmSelect;
    private ArrayList<Object[]> listaResConsulta = new ArrayList<>();
    private CtrlAdminJson controlarJson = new CtrlAdminJson();
    private CtrlAdminFicheroObjeto controlarFicheroObj = new CtrlAdminFicheroObjeto();
    //--------------------------------------------------------------------------
    public PantallaPrincipal() {
        //Inicializo la pantalla de inicio
        this.inicio = new PantallaInicial(this,true);
        //La muestro
        this.inicio.setVisible(true);
        //En caso de que la conexión sea correcta, muestro la pantalla principal,
        //si no, me salgo del porgrama
        if(this.inicio.getSeAvanza()){
            this.estaConectada = this.estaIniciada(this.inicio.getDatosCon());
            initComponents();
            this.setLocationRelativeTo(null);
            this.setTitle("Metadatos");
            this.bAnadirSelec.setVisible(false);
            this.bAnadirTodos.setVisible(false);
            this.bQuitarSelec.setVisible(false);
            this.bQuitarTodos.setVisible(false);
            this.cbCampos.removeAllItems();
            this.cbOperadores.removeAllItems();
            this.cbOperadoresLogicos.removeAllItems();
            this.cbTablas.removeAllItems();
            this.sentenciaSelect = "SELECT ";
            this.sentenciaFrom = "FROM";
            this.sentenciaWhere = "WHERE ";
            this.anadirOperLogicos();
            this.listaTablas = this.controlarCon.getTablas();
            this.anadirTablas();
        }else{
            JOptionPane.showMessageDialog(null, "¡Hasta la próxima!");
            System.exit(0);
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labTabla = new javax.swing.JLabel();
        cbTablas = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCampos = new javax.swing.JTable();
        bAnadirSelec = new javax.swing.JButton();
        bAnadirTodos = new javax.swing.JButton();
        bQuitarSelec = new javax.swing.JButton();
        bQuitarTodos = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabCamposSelec = new javax.swing.JTable();
        labCampo = new javax.swing.JLabel();
        labOperador = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabCondiciones = new javax.swing.JTable();
        cbCampos = new javax.swing.JComboBox<>();
        cbOperadores = new javax.swing.JComboBox<>();
        labValor1 = new javax.swing.JLabel();
        labValor2 = new javax.swing.JLabel();
        txtValor1 = new javax.swing.JTextField();
        txtValor2 = new javax.swing.JTextField();
        cbOperadoresLogicos = new javax.swing.JComboBox<>();
        bMasCond = new javax.swing.JButton();
        bMenosCond = new javax.swing.JButton();
        labSenSelect = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtArSelect = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabSelect = new javax.swing.JTable();
        bExportar = new javax.swing.JButton();
        bEjecutar = new javax.swing.JButton();
        bRellenarTxtAr = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labTabla.setText("Tabla");

        cbTablas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbTablas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbTablasActionPerformed(evt);
            }
        });

        tabCampos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Campos"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabCampos);

        bAnadirSelec.setText(">");
        bAnadirSelec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirSelecActionPerformed(evt);
            }
        });

        bAnadirTodos.setText(">>");
        bAnadirTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirTodosActionPerformed(evt);
            }
        });

        bQuitarSelec.setText("<");
        bQuitarSelec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bQuitarSelecActionPerformed(evt);
            }
        });

        bQuitarTodos.setText("<<");
        bQuitarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bQuitarTodosActionPerformed(evt);
            }
        });

        tabCamposSelec.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Campos Seleccionados"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tabCamposSelec);

        labCampo.setText("Campo");

        labOperador.setText("Operador");

        tabCondiciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Condición", "Operador"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tabCondiciones);

        cbCampos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbCampos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCamposActionPerformed(evt);
            }
        });

        cbOperadores.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        labValor1.setText("Valor 1");

        labValor2.setText("Valor 2");

        cbOperadoresLogicos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        bMasCond.setText("+");
        bMasCond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMasCondActionPerformed(evt);
            }
        });

        bMenosCond.setText("-");
        bMenosCond.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMenosCondActionPerformed(evt);
            }
        });

        labSenSelect.setText("Sentencia Select");

        txtArSelect.setEditable(false);
        txtArSelect.setColumns(20);
        txtArSelect.setRows(5);
        jScrollPane4.setViewportView(txtArSelect);

        tabSelect.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tabSelect);

        bExportar.setText("Exportar");
        bExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bExportarActionPerformed(evt);
            }
        });

        bEjecutar.setText("Ejecutar");
        bEjecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEjecutarActionPerformed(evt);
            }
        });

        bRellenarTxtAr.setText("Rellenar Text Area");
        bRellenarTxtAr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bRellenarTxtArActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cbTablas, 0, 102, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bAnadirSelec, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bQuitarSelec, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bQuitarTodos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bAnadirTodos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labOperador, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbCampos, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbOperadores, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(cbOperadoresLogicos, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(bMasCond))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(labValor2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtValor2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(labValor1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtValor1)))
                                .addGap(62, 62, 62))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(bMenosCond)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bExportar))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(labSenSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(bRellenarTxtAr))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(bEjecutar))))
                        .addGap(0, 17, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labTabla)
                    .addComponent(cbTablas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labCampo)
                    .addComponent(cbCampos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labValor1)
                    .addComponent(txtValor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(bAnadirSelec, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bAnadirTodos, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bQuitarSelec, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bQuitarTodos))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(labOperador)
                                    .addComponent(cbOperadores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labValor2)
                                    .addComponent(txtValor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cbOperadoresLogicos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bMasCond))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(bMenosCond)
                                        .addGap(61, 61, 61))))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labSenSelect)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bRellenarTxtAr)
                        .addGap(52, 52, 52)
                        .addComponent(bEjecutar)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(bExportar)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbTablasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbTablasActionPerformed
        if(this.cbTablas.getSelectedItem() != null){
            String tabla = this.cbTablas.getSelectedItem().toString();
            if(this.sentenciaFrom.equals("FROM")){
                this.sentenciaFrom += " " + tabla;
            }else{
                this.sentenciaFrom = "FROM " + tabla;
            }
            this.listaCampos = this.controlarCon.getNombresColumnas(tabla);
            this.dtmCampos = (DefaultTableModel) this.tabCampos.getModel();
            this.dtmCampos.setRowCount(0);
            Object[] fila = new Object[1];
            for(String campo : this.listaCampos){
                fila[0] = campo;
                this.dtmCampos.addRow(fila);
            }
            this.bAnadirSelec.setVisible(true);
            this.bAnadirTodos.setVisible(true);
            this.bQuitarSelec.setVisible(true);
            this.bQuitarTodos.setVisible(true);
            this.cbCampos.removeAllItems();
            if(this.dtmCamposSelec != null){
                this.dtmCamposSelec.setRowCount(0);
            }
            if(this.dtmCondiciones != null){
                this.dtmCondiciones.setRowCount(0);
            }
            this.txtArSelect.setText("");
            this.sentenciaSelect = "SELECT *";
            this.sentenciaWhere = "WHERE ";
            this.bEjecutar.setVisible(false);
            if(this.dtmSelect != null){
                this.dtmSelect.setRowCount(0);
            }
            this.bExportar.setVisible(false);
        }
    }//GEN-LAST:event_cbTablasActionPerformed

    private void bAnadirSelecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirSelecActionPerformed
        this.instanciarDtmCamposSelec();
        int filaSelec = this.tabCampos.getSelectedRow();
        if(filaSelec != -1){
            boolean esta = false;
            for(int i = 0; i < this.dtmCamposSelec.getRowCount(); i++){
                //Compruebo que el registro seleccionado no esté en la tabla tabCamposSelec
                if(this.tabCampos.getValueAt(filaSelec, 0).toString().equals(this.tabCamposSelec.getValueAt(i, 0).toString())){
                    esta = true;
                }
            }
            //Si el registro no está, lo añado
            if(!esta){
                Object[] fila = {this.tabCampos.getValueAt(filaSelec, 0)};
                this.dtmCamposSelec.addRow(fila);
                this.cbCampos.addItem(fila[0].toString());
                numCampos++;
                if(numCampos == 1){
                    this.sentenciaSelect += fila[0].toString();
                }else{
                    this.sentenciaSelect += ", " + fila[0].toString();
                }
            }
        }else{
            JOptionPane.showMessageDialog(null, "Debe seleccionar un "
                    + "registro para poder pasarlo.");
        }
    }//GEN-LAST:event_bAnadirSelecActionPerformed

    private void bAnadirTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirTodosActionPerformed
        this.instanciarDtmCamposSelec();
        this.dtmCamposSelec.setRowCount(0);
        numCampos = 0;
        this.cbCampos.removeAllItems();
        Object[] fila = new Object[1];
        for(int i = 0; i < this.dtmCampos.getRowCount(); i++){
            numCampos ++;
            fila[0] = this.tabCampos.getValueAt(i, 0);
            this.sentenciaSelect += fila[0].toString() + ", ";
            this.dtmCamposSelec.addRow(fila);
            this.cbCampos.addItem(fila[0].toString());
        }
    }//GEN-LAST:event_bAnadirTodosActionPerformed

    private void bQuitarSelecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bQuitarSelecActionPerformed
        this.instanciarDtmCamposSelec();
        Object objetoBorrado = null;
        int filaSelec = this.tabCamposSelec.getSelectedRow();
        if (filaSelec != -1) {
            objetoBorrado = this.tabCamposSelec.getValueAt(filaSelec, 0);
            this.dtmCamposSelec.removeRow(filaSelec);
            this.cbCampos.removeItem(objetoBorrado);
            String aux = objetoBorrado.toString() + ", ";
            this.sentenciaSelect = this.sentenciaSelect.replaceAll(aux, "");
            numCampos--;
        } else {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un "
                    + "registro para poder quitarlo.");
        }
        
        
    }//GEN-LAST:event_bQuitarSelecActionPerformed

    private void bQuitarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bQuitarTodosActionPerformed
        this.instanciarDtmCamposSelec();
        this.dtmCamposSelec.setRowCount(0);
        this.cbCampos.removeAllItems();
        this.cbOperadores.removeAllItems();
        this.sentenciaSelect = "SELECT *";
        numCampos = 0;
        numCondiciones = 0;
    }//GEN-LAST:event_bQuitarTodosActionPerformed

    private void cbCamposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCamposActionPerformed
        //Dependiendo del tipo de dato que haya en el comboBox, se pueden utilizar una
        //serie de operadores
        if(this.cbCampos.getItemCount() > 0 && this.dtmCamposSelec.getRowCount() > 0){
            //Obtengo el camppo seleccionado en cbCampos y la tabla de cbTablas
            String campo = this.cbCampos.getSelectedItem().toString();
            String tabla = this.cbTablas.getSelectedItem().toString();
            String tipoDato = this.controlarCon.getTipoDato(tabla, campo);
            this.anadirOperadores(tipoDato);
        }else{
            this.cbOperadores.removeAllItems();
        }
        
        
        
        
    }//GEN-LAST:event_cbCamposActionPerformed

    private void bMasCondActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMasCondActionPerformed
        this.dtmCondiciones = (DefaultTableModel) this.tabCondiciones.getModel();
        String valor1 = this.txtValor1.getText();
        String valor2 = this.txtValor2.getText();
        String tabla = "";
        String campo = "";
        String operador = "";
        String opLogico = this.cbOperadoresLogicos.getSelectedItem().toString();
        String tipoDato = "";
        String condicion = "";
        boolean sonCorrectos = false;
        int esNumero = -5;
        
        if(this.cbCampos.getItemCount() > 0 && this.cbOperadores.getItemCount() > 0){
            tabla = this.cbTablas.getSelectedItem().toString();
            campo = this.cbCampos.getSelectedItem().toString();
            operador = this.cbOperadores.getSelectedItem().toString();
            tipoDato = this.controlarCon.getTipoDato(tabla, campo);
            sonCorrectos = true;
        }
        
        if(valor1.isEmpty()){
            sonCorrectos = false;
            JOptionPane.showMessageDialog(null, "Valor 1 no "
                    + "no puede estar vacío.");
        }else{
            sonCorrectos = true;
        }
        
        if(sonCorrectos){
            switch(tipoDato) {
                //El multicase solo puede hacerse desde la versión 14 y yo uso la 11
                case "String":
                    valor1 = "'" + valor1 + "'";
                    if(operador.equals("LIKE")){
                        condicion = campo + " " + operador + " " + valor1;
                    }else{
                        condicion = campo + " " + operador + " " + valor1;
                    }
                    break;
                case "Date":
                    valor1 = "'" + valor1 + "'";
                    if (operador.equals("LIKE")) {
                        condicion = campo + " " + operador + " (" + valor1 + ")";
                    } else {
                        condicion = campo + " " + operador + " " + valor1;
                    }
                    break;
                case "double":
                    esNumero = this.esUnNumero(valor1);
                    if(valor2.isEmpty()){
                        valor2 = "0";
                    }else{
                        esNumero = this.esUnNumero(valor2);
                    }
                    if(esNumero == 0){
                        switch(operador) {
                            case "BETWEEN":
                                condicion = campo + " " + operador + " " + valor1 + " AND " + valor2;
                                break;
                            case "IN":
                                condicion = campo + " " + operador + " (" + valor1 + "," + valor2 + ")";
                                break;
                            default:
                                condicion = campo + " " + operador + " " + valor1;
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Si quiere "
                                + "comparar números, debe introducir números.");
                    }
                    break;
            }
            Object[] fila = new Object[2];
            fila[0] = condicion;
            fila[1] = opLogico;
            boolean esta = false;
            //Compruebo que la instrucción no esté agregada
            for(int i = 0; i < this.dtmCondiciones.getRowCount(); i++){
                if(this.dtmCondiciones.getValueAt(i, 0).toString().equals(condicion)){
                    esta = true;
                }
            }
            if(!esta){
                this.dtmCondiciones.addRow(fila);
                numCondiciones++;
                String aux;
                if(numCondiciones == 1){
                    this.sentenciaWhere += condicion + " " + opLogico + " ";
                }else{
                    this.sentenciaWhere += condicion + " " + opLogico + " ";
                }
            }else{
                JOptionPane.showMessageDialog(null, "No puede "
                        + "añadir la misma condición dos veces.");
            }
            
            
            
        }
    }//GEN-LAST:event_bMasCondActionPerformed

    private void bMenosCondActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMenosCondActionPerformed
        if(this.dtmCondiciones != null && this.dtmCondiciones.getRowCount() > 0){
            int filaSelec = this.tabCondiciones.getSelectedRow();
            if(filaSelec != -1){
                String condicionBorrada = this.dtmCondiciones.getValueAt(filaSelec, 0).toString();
                String opBorrado = this.dtmCondiciones.getValueAt(filaSelec, 1).toString();
                this.dtmCondiciones.removeRow(filaSelec);
                String relacionBorrada = condicionBorrada + " " + opBorrado;
                this.sentenciaWhere = this.sentenciaWhere.replaceAll(relacionBorrada, "");
                numCondiciones--;
            }else{
                JOptionPane.showMessageDialog(null, "Seleccione la "
                    + "condición que quiera borrar.");
            }
        }else{
            JOptionPane.showMessageDialog(null, "No puede borrar "
                    + "una condición que no existe.");
        }
    }//GEN-LAST:event_bMenosCondActionPerformed

    private void bRellenarTxtArActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRellenarTxtArActionPerformed
        if(numCampos > 0){
            int penultimoIndice = this.sentenciaSelect.length() - 2;
            if(this.sentenciaSelect.charAt(penultimoIndice) == ','){
                this.sentenciaSelect = this.sentenciaSelect.substring(0, penultimoIndice);
            }
            this.sentenciaSelect = this.sentenciaSelect.replaceAll("\\*", "");
        }else{
            this.sentenciaSelect = "SELECT *";
        }
        String textArea = this.sentenciaSelect + "\n";
        textArea += this.sentenciaFrom + "\n";
        if(!this.sentenciaWhere.equals("WHERE ")){
            textArea += this.sentenciaWhere;
        }
        this.txtArSelect.setText(textArea);
        this.bEjecutar.setVisible(true);
    }//GEN-LAST:event_bRellenarTxtArActionPerformed

    private void bEjecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEjecutarActionPerformed
        String ins = this.sentenciaSelect + " " + this.sentenciaFrom + " ";
        if (!this.sentenciaWhere.equals("WHERE ")) {
            this.sentenciaWhere = this.sentenciaWhere.substring(0, this.sentenciaWhere.length() - 4);
            ins += this.sentenciaWhere;
        }
        if(!ins.isEmpty()){
            String msj = this.controlarCon.ejecutarConsulta(ins);
            if(msj.isEmpty()){
                int numColumnas = this.controlarCon.getNumColumnas();
                this.dtmSelect = (DefaultTableModel) this.tabSelect.getModel();
                this.dtmSelect.setRowCount(0);
                this.dtmSelect.setColumnCount(numColumnas);
                Object[] nombresColumnas = new Object[numColumnas];
                //Genero el nombre de las columnas
                for(int i = 1; i <= numColumnas; i++){
                    nombresColumnas[i - 1] = this.controlarCon.getNombreColumna(i);
                }
                //Obtengo los datos qeu devuelve la consulta
                boolean hayDatos = true;
                Object[] fila = new Object[numColumnas];
                while(hayDatos = this.controlarCon.hayMasDatos()){
                    for(int i = 1; i <= numColumnas; i++){
                        String dato = "";
                        String nombreColumna = nombresColumnas[i - 1].toString();
                        String tipoColumna = this.controlarCon.getTipoColumna(i, nombreColumna);
                        dato = this.controlarCon.getCampo(tipoColumna, nombreColumna, hayDatos);
                        fila[i - 1] = dato;
                    }
                    this.dtmSelect.addRow(fila);
                    this.bExportar.setVisible(true);
                }
                this.dtmSelect.setColumnIdentifiers(nombresColumnas);
            } else {
                JOptionPane.showMessageDialog(null, msj);
            }
        }
    }//GEN-LAST:event_bEjecutarActionPerformed

    private void bExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bExportarActionPerformed
        //No hace falta comprobar que la tabla esté vacía, ya que si se hace visible este botón,
        //no lo está
        int numFilas = this.dtmSelect.getRowCount();
        int numColumnas = this.dtmSelect.getColumnCount();
        for(int i = 0; i < numFilas; i++){
            Object[] fila = new Object[numColumnas];
            for(int j = 0; j < numColumnas; j++){
                fila[j] = this.dtmSelect.getValueAt(i, j);
            }
            this.listaResConsulta.add(fila);
        }
        if(this.controlarJson.crearFicheroJson(this.listaResConsulta)){
            JOptionPane.showMessageDialog(null, "Se han exportado "
                    + "los datos al fichero " + this.controlarJson.getFileName());
        }
        if(this.controlarFicheroObj.escribirLista(this.listaResConsulta)){
            JOptionPane.showMessageDialog(null, "Se han exportado "
                    + "los datos al fichero " + this.controlarFicheroObj.getFileName());
        }
        
    }//GEN-LAST:event_bExportarActionPerformed
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaPrincipal().setVisible(true);
            }
        });
    }
    
    
    //Métodos auxiliares
    //Este método sirve para filtrar el tipo de dato que se le pasa por parámetro
    //y devolver para que pueda entenderse en SQL
    private String filtrarDato(String valor){
        double aux= 0;
        try{
            //Compruebo si es un número
            aux = Double.parseDouble(valor);
        } catch(NumberFormatException ex) {
            valor = "'" + valor + "'";
        } finally{
            return valor;
        }
    }
    //Este método sirve para saber si el String que se le pasa como parámetro contiene
    //un número. Si es un número devuelvo 0, si no -1
    private int esUnNumero(String valor){
        int loEs = 0;
        try{
            double aux = Double.parseDouble(valor);
        } catch(NumberFormatException ex) {
            loEs = -1;
        } finally {
            return loEs;
        }
        
    }
    //Este método sirve para asignar los operadores en función del tipo de tipoDato
    //que se vaya a comparar
    private void anadirOperadores(String tipoDato){
        String mayor = ">";
        String menor = "<";
        String igual = "=";
        String menorIgual = "<=";
        String mayorIgual = ">=";
        String distinto = "!=";
        String between = "BETWEEN";
        String in = "IN";
        String like = "LIKE";
        this.cbOperadores.removeAllItems();
        switch(tipoDato){
            case "String":
                this.cbOperadores.addItem(mayor);
                this.cbOperadores.addItem(menor);
                this.cbOperadores.addItem(igual);
                this.cbOperadores.addItem(menorIgual);
                this.cbOperadores.addItem(mayorIgual);
                this.cbOperadores.addItem(distinto);
                this.cbOperadores.addItem(like);
                break;
            case "double":
                this.cbOperadores.addItem(mayor);
                this.cbOperadores.addItem(menor);
                this.cbOperadores.addItem(igual);
                this.cbOperadores.addItem(menorIgual);
                this.cbOperadores.addItem(mayorIgual);
                this.cbOperadores.addItem(distinto);
                this.cbOperadores.addItem(between);
                this.cbOperadores.addItem(in);
                break;
            case "Date":
                this.cbOperadores.addItem(mayor);
                this.cbOperadores.addItem(menor);
                this.cbOperadores.addItem(igual);
                this.cbOperadores.addItem(menorIgual);
                this.cbOperadores.addItem(mayorIgual);
                this.cbOperadores.addItem(distinto);
                break;
            default:
                this.cbOperadores.removeAllItems();
        }
    }
    //Este método sirve para añadir los operados lógicos a cbOperadoresLogicos
    private void anadirOperLogicos(){
        this.cbOperadoresLogicos.addItem("AND");
        this.cbOperadoresLogicos.addItem("OR");
    }
    //Este método instancia dtmCamposSelec si no lo está
    private void instanciarDtmCamposSelec(){
        if(this.dtmCamposSelec == null){
            this.dtmCamposSelec = (DefaultTableModel) this.tabCamposSelec.getModel();
        }
    }
    //Este método sirve para añadir listaTablas a cbTablas
    private void anadirTablas(){
        this.cbTablas.removeAllItems();
        for(String tabla : this.listaTablas){
            this.cbTablas.addItem(tabla);
        }
    }
    //Este método sirve para iniciar la conexión a la base de datos
    private boolean estaIniciada(String[] datos){
        boolean estaIniciada = false;
        if(this.controlarCon.conectar(datos[0], datos[1], datos[2], datos[3]) != null){
            estaIniciada = true;
        }
        return estaIniciada;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAnadirSelec;
    private javax.swing.JButton bAnadirTodos;
    private javax.swing.JButton bEjecutar;
    private javax.swing.JButton bExportar;
    private javax.swing.JButton bMasCond;
    private javax.swing.JButton bMenosCond;
    private javax.swing.JButton bQuitarSelec;
    private javax.swing.JButton bQuitarTodos;
    private javax.swing.JButton bRellenarTxtAr;
    private javax.swing.JComboBox<String> cbCampos;
    private javax.swing.JComboBox<String> cbOperadores;
    private javax.swing.JComboBox<String> cbOperadoresLogicos;
    private javax.swing.JComboBox<String> cbTablas;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel labCampo;
    private javax.swing.JLabel labOperador;
    private javax.swing.JLabel labSenSelect;
    private javax.swing.JLabel labTabla;
    private javax.swing.JLabel labValor1;
    private javax.swing.JLabel labValor2;
    private javax.swing.JTable tabCampos;
    private javax.swing.JTable tabCamposSelec;
    private javax.swing.JTable tabCondiciones;
    private javax.swing.JTable tabSelect;
    private javax.swing.JTextArea txtArSelect;
    private javax.swing.JTextField txtValor1;
    private javax.swing.JTextField txtValor2;
    // End of variables declaration//GEN-END:variables
}
